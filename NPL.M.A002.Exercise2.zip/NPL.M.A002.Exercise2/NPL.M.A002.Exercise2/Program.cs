﻿using System;

namespace NPL.M.A002.Exercise2
{
    internal class Program
    {
        private double CalculateBMI(double weight, double height)
        {
            double bmi;
            bmi = weight / ((height / 100.0) * (height / 100.0));

            return bmi;
        }
        private string BMIEvaluate(double bmi)
        {
            string result = null;

            if (bmi > 0)
            {
                if (bmi < 18.5)
                {
                    Console.Write(" Your BMI:" + bmi);
                    Console.WriteLine();
                    result = " Status: Underweight";
                    Console.Write(result);
                }
                else if (bmi >= 18.5 && bmi <= 24.9)
                {
                    Console.Write(" Your BMI:" + bmi);
                    Console.WriteLine();
                    result = " Status: Normal weight";
                    Console.Write(result);
                }
                else if (bmi >= 25.0 && bmi <= 29.9)
                {
                    Console.Write(" Your BMI:" + bmi);
                    Console.WriteLine();
                    result = " Status: Overweight";
                    Console.Write(result);
                }
                else if (bmi >= 30.0 && bmi <= 34.9)
                {
                    Console.Write(" Your BMI:" + bmi);
                    Console.WriteLine();
                    result = " Status: Class I obesity";
                    Console.Write(result);
                }
                else if (bmi >= 35.0 && bmi <= 39.9)
                {
                    Console.Write(" Your BMI:" + bmi);
                    Console.WriteLine();
                    result = " Status: Class II obesity";
                    Console.Write(result);
                }
                else if (bmi >= 40)
                {
                    Console.Write(" Your BMI:" + bmi);
                    Console.WriteLine();
                    result = " Status: Class III obesity";
                    Console.Write(result);
                }
            }
            else
            {
                result = " Status: Unknown";
                Console.Write(result);
            }

            return result;
        }
        private static void Main(string[] args)
        {
            Program prg = new Program();
            double weight;
            double height;
            double bmi = 0;

            Console.Write("Input Weight(kg): ");
            weight = double.Parse(Console.ReadLine());
            Console.Write("Input Height(cm): ");
            height = double.Parse(Console.ReadLine());

            

            if (height <= 0 || weight <= 0)
            {
                Console.WriteLine("Error");
            }
            else
            {
                double convertHeight = height / 100.0;
                Console.Write("Input Height(m): " + convertHeight);
                bmi = prg.CalculateBMI(weight, height);
            }
            Console.WriteLine();

            string evaluate;
            evaluate = prg.BMIEvaluate(bmi);

            Console.ReadKey();
        }
    }
}
